"""
Ops - Infraestrutura e Operações

Módulos de infraestrutura genérica que podem ser reutilizados
em qualquer projeto Python/API.
"""

__version__ = "1.0.0"